﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;

namespace gautamj.Controllers
{
    public class HomeController : Controller
    {
        private readonly string _connectionString;

        public HomeController()
        {
            _connectionString = "Server=10.10.10.93,1433;Database=master;User Id=gautamj;Password=Welcome123$$;Encrypt=False;";
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SavePersonalInfo(int PostID, string Title, string Content, string Author, DateTime CreatedAt)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO Detail.dbo.BlogPosts (PostID, Title, Content, Author, CreatedAt) VALUES (@PostID, @Title, @Content, @Author, @CreatedAt)";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@PostID", PostID);
                        command.Parameters.AddWithValue("@Title", Title);
                        command.Parameters.AddWithValue("@Content", Content);
                        command.Parameters.AddWithValue("@Author", Author);
                        command.Parameters.AddWithValue("@CreatedAt", CreatedAt);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            return Json(new { success = true, message = "Post saved successfully" });
                        }
                        else
                        {
                            return Json(new { success = false, message = "Failed to save post" });
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                return Json(new { success = false, message = "An error occurred while saving post: " + ex.Message });
            }

        }

        public IActionResult ViewRecords()
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    string query = "SELECT * FROM Detail.dbo.BlogPosts";

                    using (var command = new SqlCommand(query, connection))
                    {
                        var posts = new List<BlogPost>();
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var post = new BlogPost
                                {
                                    PostID = reader.GetInt32(reader.GetOrdinal("PostID")),
                                    Title = reader.GetString(reader.GetOrdinal("Title")),
                                    Content = reader.GetString(reader.GetOrdinal("Content")),
                                    Author = reader.GetString(reader.GetOrdinal("Author")),
                                    CreatedAt = reader.GetDateTime(reader.GetOrdinal("CreatedAt"))
                                };
                                posts.Add(post);
                            }
                        }
                        return View(posts);
                    }
                }
            }
            catch (SqlException ex)
            {
                return Content("Error occurred: " + ex.Message);
            }
        }

        public IActionResult Edit(int PostID)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    string query = "SELECT * FROM Detail.dbo.BlogPosts WHERE PostID = @PostID";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@PostID", PostID);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                var blog = new BlogPost
                                {
                                    PostID = reader.GetInt32(reader.GetOrdinal("PostID")),
                                    Title = reader.GetString(reader.GetOrdinal("Title")),
                                    Content = reader.GetString(reader.GetOrdinal("Content")),
                                    Author = reader.GetString(reader.GetOrdinal("Author")),
                                    CreatedAt = reader.GetDateTime(reader.GetOrdinal("CreatedAt"))
                                };

                                return View(blog);
                            }
                            else
                            {
                                return NotFound();
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                return Content("Error occurred: " + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult Edit(BlogPost blog)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    string query = "UPDATE Detail.dbo.BlogPosts SET PostID = @PostID, Title = @Title, Content = @Content, Author = @Author, CreatedAt = @CreatedAt WHERE PostID = @PostID";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@PostID", blog.PostID);
                        command.Parameters.AddWithValue("@Title", blog.Title);
                        command.Parameters.AddWithValue("@Content", blog.Content);
                        command.Parameters.AddWithValue("@Author", blog.Author);
                        command.Parameters.AddWithValue("@CreatedAt", blog.CreatedAt);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            return RedirectToAction("ViewRecords");
                        }
                        else
                        {
                            return NotFound();
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                return Content("Error occurred: " + ex.Message);
            }
        }
        [HttpPost]
        public IActionResult Delete(string PostID)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    string query = "DELETE FROM Detail.dbo.BlogPosts WHERE PostID = @PostID";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@PostID", PostID);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                        // Deletion successful
                            return RedirectToAction("ViewRecords");
                        }
                        else
                        {
                        // Record not found or deletion failed
                            return NotFound();
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
            // Handle exceptions appropriately
                return Content("Error occurred: " + ex.Message);
            }
        }
    }
}

namespace gautamj
{
    public class BlogPost
    {
        public int PostID { get; set; }
        public required string Title { get; set; }
        public required string Content { get; set; }
        public required string Author { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
